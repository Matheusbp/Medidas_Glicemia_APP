# Medidas_Glicemia_APP
App para visualizar os dados de glicemia, insulina aplicada, carboidratos ingeridos e quantidade de comida. 

-tive que mdnar para o container da lightsail com o aws-cli, e tem que abrir a porta que está especificada no dockerfile, mais especificamente no options do shiny server