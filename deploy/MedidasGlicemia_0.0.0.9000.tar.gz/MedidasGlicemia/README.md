# Medidas_Glicemia_APP
App para visualizar os dados de glicemia, insulina aplicada, carboidratos ingeridos e quantidade de comida. 
